export const services = [
    {
        title: "Ücretsiz Kargo",
        tagline: "200TL üzeri tüm siparişlerde",
        image: "images/service.png",
    },
    {
        title: "Günlük Süpriz Teklifler",
        tagline: "%25'e varan indirim",
        image: "images/service-02.png",
    },
    {
        title: "7/24 Destek",
        tagline: "Uzmanla alişveriş yap",
        image: "images/service-03.png",
    },
    {
        title: "Uygun Fiyatlar",
        tagline: "Fabrika Satiş Fiyatina Al",
        image: "images/service-04.png",
    },
    {
        title: "Güvenli Ödeme",
        tagline: "%100 Korumali Ödeme",
        image: "images/service-05.png",
    },
];